#!/bin/sh

# exit on error
set -e
# turn on command echoing
set -v

rm -rf start spec temp out
