#!/usr/bin/env python

import sys, os
sys.path.append("../../tool")
import mpl_helper
import scipy.io, numpy

(figure, axes1) = mpl_helper.make_fig(top_margin=0.3,right_margin=1.5)
#axes2 = axes1.twinx()

ncf = scipy.io.netcdf_file("out/urban_plume_process.nc")
time = ncf.variables["time"].data.copy() / 3600

gas_mass = ncf.variables["gas_mass"].data.copy()
aer_mass = ncf.variables["aer_mass"].data.copy()
#ole1_mass = ncf.variables["tot_ole1_mass_conc"].data.copy() #
#alk1_mass = ncf.variables["tot_alk1_mass_conc"].data.copy() 
total_mass = (gas_mass + aer_mass )


axes1.errorbar(time, gas_mass, fmt="r-", label='gas')
axes1.errorbar(time, aer_mass, fmt="b-", label='aer')
#axes1.errorbar(time, ole1_mass, fmt="b-", label='ole1')
#axes1.errorbar(time, alk1_mass, fmt="g-", label='alk1')
axes1.errorbar(time, total_mass, fmt="gold", label='total')

axes1.set_xlabel(r"time / h")

axes1.set_ylabel(r"conc. / $\rm kg\ m^{-3} $")
#axes1.set_ylabel(r"ole1 mass conc. / $\rm kg\ $")
#axes1.set_xticks(numpy.arange(0,25,1))
#axes1.set_yticks(numpy.arange(0,5.0E-7,1.0e-7))
#axes2.set_yticks(numpy.arange(0,4.0e-8,1.0e-8))
axes1.legend(loc='lower center', bbox_to_anchor=(1.3, -0.15))
#axes2.legend(loc='lower center', bbox_to_anchor=(1.4, 0.15))
#axes3.legend(loc='lower center', bbox_to_anchor=(1.0, 1.05))
axes1.grid(True)

out_filename = "out/urban_plume_mb1.pdf"
print("Writing %s" % out_filename)
figure.savefig(out_filename)

