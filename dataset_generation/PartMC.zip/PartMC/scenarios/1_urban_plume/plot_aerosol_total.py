#!/usr/bin/env python

import sys, os
sys.path.append("../../tool")
import mpl_helper
import scipy.io, numpy

(figure, axes1) = mpl_helper.make_fig(top_margin=0.3,right_margin=1.5)
#axes2 = axes1.twinx()
#axes3 = axes1.twinx()

ncf = scipy.io.netcdf_file("out/urban_plume_process.nc")
time = ncf.variables["time"].data.copy() / 3600
ole1_mass_conc = ncf.variables["ole1_mass"].data.copy() #/ 1e6
#ole1_mass_conc_err = ncf.variables["tot_ole1_mass_conc_ci_offset"].data.copy() #/ 1e6
so4_mass_conc = ncf.variables["tot_so4_mass_conc"].data.copy() #/ 1e6
so4_mass_conc_err = ncf.variables["tot_so4_mass_conc_ci_offset"].data.copy() #/ 1e6
nh4_mass_conc = ncf.variables["tot_nh4_mass_conc"].data.copy() #/ 1e6
nh4_mass_conc_err = ncf.variables["tot_nh4_mass_conc_ci_offset"].data.copy() #/ 1e6
oc_mass_conc = ncf.variables["tot_oc_mass_conc"].data.copy() #/ 1e6
oc_mass_conc_err = ncf.variables["tot_oc_mass_conc_ci_offset"].data.copy() #/ 1e6
bc_mass_conc = ncf.variables["tot_bc_mass_conc"].data.copy() #/ 1e9
bc_mass_conc_err = ncf.variables["tot_bc_mass_conc_ci_offset"].data.copy() #/ 1e9

co3_mass_conc = ncf.variables["tot_co3_mass_conc"].data.copy() #/ 1e9
co3_mass_conc_err = ncf.variables["tot_co3_mass_conc_ci_offset"].data.copy() #/ 1e9
oin_mass_conc = ncf.variables["tot_oin_mass_conc"].data.copy() #/ 1e9
oin_mass_conc_err = ncf.variables["tot_oin_mass_conc_ci_offset"].data.copy() #/ 1e9
ca_mass_conc = ncf.variables["tot_ca_mass_conc"].data.copy() #/ 1e9
ca_mass_conc_err = ncf.variables["tot_ca_mass_conc_ci_offset"].data.copy() #/ 1e9

mass_conc = (ole1_mass_conc+so4_mass_conc+nh4_mass_conc+oc_mass_conc+bc_mass_conc+co3_mass_conc+oin_mass_conc+ca_mass_conc)*1.01
#mass_conc_err = ncf.variables["tot_mass_conc_ci_offset"].data.copy() #* 1e9

#axes1.errorbar(time, mass_conc,  fmt="r-", label='Total')
axes1.errorbar(time, ole1_mass_conc, fmt="b-", label='OLE1')
axes1.errorbar(time, so4_mass_conc, so4_mass_conc_err, fmt="deeppink", label='SO4')
axes1.errorbar(time, nh4_mass_conc, nh4_mass_conc_err, fmt="navy", label='NH4')
axes1.errorbar(time, oc_mass_conc, oc_mass_conc_err, fmt="gold", label='OC')
axes1.errorbar(time, bc_mass_conc, bc_mass_conc_err, fmt="purple", label='BC')
axes1.errorbar(time, co3_mass_conc, co3_mass_conc_err, fmt="seagreen", label='CO3')
axes1.errorbar(time, oin_mass_conc, oin_mass_conc_err, fmt="tan", label='OIN')
axes1.errorbar(time, ca_mass_conc, ca_mass_conc_err, fmt="yellow", label='Ca')
axes1.set_xlabel(r"time / h")

axes1.set_ylabel(r"conc. / $\rm kg\ m^{-3}$")

axes1.set_xticks(numpy.arange(0,27,3))
#axes1.set_yticks(numpy.arange(0,1.0e-6,5.0e-7))

axes1.legend(loc='lower center', bbox_to_anchor=(1.3, -0.15))
#axes2.legend(loc='lower center', bbox_to_anchor=(0.6, 1.05))
#axes3.legend(loc='lower center', bbox_to_anchor=(1.0, 1.05))
axes1.grid(True)

out_filename = "out/urban_plume_aerosol_total.pdf"
print("Writing %s" % out_filename)
figure.savefig(out_filename)

