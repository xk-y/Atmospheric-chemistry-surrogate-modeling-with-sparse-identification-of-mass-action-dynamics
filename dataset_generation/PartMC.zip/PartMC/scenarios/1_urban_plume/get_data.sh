#!/bin/sh
source activate partmc

echo start 

# execute
echo start 0_get_nc
python 0_get_nc.py

echo start 1_get_csv
python 1_get_csv.py

echo finished!
