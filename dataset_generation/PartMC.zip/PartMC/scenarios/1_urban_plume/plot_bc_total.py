#!/usr/bin/env python

import sys, os
sys.path.append("../../tool")
import mpl_helper
import scipy.io, numpy

(figure, axes) = mpl_helper.make_fig(top_margin=0.6,right_margin=0.8)
axes2 = axes.twinx()

ncf = scipy.io.netcdf_file("out/urban_plume_process.nc")
time = ncf.variables["time"].data.copy() / 3600
bc_mass_conc = ncf.variables["tot_bc_mass_conc"].data.copy() #/ 1e9
bc_mass_conc_err = ncf.variables["tot_bc_mass_conc_ci_offset"].data.copy() #/ 1e9
mass_conc = ncf.variables["tot_mass_conc"].data.copy() #* 1e9
mass_conc_err = ncf.variables["tot_mass_conc_ci_offset"].data.copy() #* 1e9

axes.errorbar(time, bc_mass_conc, bc_mass_conc_err, fmt="b-", label='bc conc.')
axes2.errorbar(time, mass_conc, mass_conc_err, fmt="r-", label='mass conc.')
axes.set_xlabel(r"time / h")
axes.set_ylabel(r"bc conc. / $\rm kg\ m^{-3}$")
axes2.set_ylabel(r"mass conc. / $\rm kg\ m^{-3}$")
axes.set_yticks(numpy.arange(0,4.0e-8,1.0e-8))
axes2.set_yticks(numpy.arange(0,4.0e-8,1.0e-8))
axes.legend(loc='lower center', bbox_to_anchor=(0.2, 1.05))
axes2.legend(loc='lower center', bbox_to_anchor=(0.6, 1.05))
axes.grid(True)

out_filename = "out/urban_plume_bc.pdf"
print("Writing %s" % out_filename)
figure.savefig(out_filename)
