#!/usr/bin/env python

import sys, os
sys.path.append("../../tool")
import mpl_helper
import scipy.io, numpy

(figure, axes1) = mpl_helper.make_fig(top_margin=0.3,right_margin=1.5)
#axes2 = axes1.twinx()
#axes3 = axes1.twinx()

ncf = scipy.io.netcdf_file("out/urban_plume_process.nc")
time = ncf.variables["time"].data.copy() / 3600

c4h6_gas_conc = ncf.variables["c4h6_gas_conc"].data.copy() #/ 1e6
o3_gas_conc = ncf.variables["o3_gas_conc"].data.copy() 
hcho_gas_conc = ncf.variables["hcho_gas_conc"].data.copy() 
#ACO3H_gas_conc =  ncf.variables["ACO3H_gas_conc"].data.copy() 
#total_gas_mass = ncf.variables["gas_mass"].data.copy() 



axes1.errorbar(time, c4h6_gas_conc, fmt="r-", label='C4H6')
axes1.errorbar(time, o3_gas_conc, fmt="b-", label='O3')
axes1.errorbar(time, hcho_gas_conc, fmt="gold", label='HCHO ')
#axes1.errorbar(time, ACO3H_gas_conc, fmt="green", label='ACO3H ')
#axes1.errorbar(time, MVKOHAOH_gas_conc, fmt="green", label='MVKOHAOH')

#axes1.errorbar(time, total_gas_mass, fmt="deeppink", label='TOTAL')

axes1.set_xlabel(r"time / h")

axes1.set_ylabel(r"conc. / $\rm kg\ m^{-3}$")
#axes2.set_ylabel(r"conc. / $\rm molec/cc$")

#axes1.set_xticks(numpy.arange(0,25,1))

#axes2.set_yticks(numpy.arange(0,1.0e+5,1.0e+4))

axes1.legend(loc='lower center', bbox_to_anchor=(1.3, -0.15))
#axes2.legend(loc='lower center', bbox_to_anchor=(1.3, 0.30))
#axes3.legend(loc='lower center', bbox_to_anchor=(1.0, 1.05))
axes1.grid(True)

out_filename = "out/urban_plume_gas.pdf"
print("Writing %s" % out_filename)
figure.savefig(out_filename)

