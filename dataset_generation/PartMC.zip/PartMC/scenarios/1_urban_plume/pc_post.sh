#!/bin/sh

# exit on error
set -e
# turn on command echoing
set -v
# run the postprocessing 
/home/xiaokai/Desktop/PartMC-MOSAIC-MCMv3.3.1/PartMC/build/get_psd_bins_2d &> get_psd_bins_2d.log
