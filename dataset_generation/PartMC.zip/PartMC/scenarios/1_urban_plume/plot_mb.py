#!/usr/bin/env python

import sys, os
sys.path.append("../../tool")
import mpl_helper
import scipy.io, numpy

(figure, axes1) = mpl_helper.make_fig(top_margin=0.3,right_margin=1.5)
#axes2 = axes1.twinx()

ncf = scipy.io.netcdf_file("out/urban_plume_process.nc")
time = ncf.variables["time"].data.copy() / 3600

gas_mass = ncf.variables["gas_mass"].data.copy() 
ole1_mass = ncf.variables["tot_ole1_mass_conc"].data.copy() #
alk1_mass = ncf.variables["tot_alk1_mass_conc"].data.copy()
aro1_mass = ncf.variables["tot_aro1_mass_conc"].data.copy() 
aro2_mass = ncf.variables["tot_aro2_mass_conc"].data.copy() 
api1_mass = ncf.variables["tot_api1_mass_conc"].data.copy() 
api2_mass = ncf.variables["tot_api2_mass_conc"].data.copy() 
lim1_mass = ncf.variables["tot_lim1_mass_conc"].data.copy() 
lim2_mass = ncf.variables["tot_lim2_mass_conc"].data.copy()  
total_mass = (ole1_mass + alk1_mass + aro1_mass + aro2_mass + 
              api1_mass + api2_mass + lim1_mass + lim2_mass)


#axes1.errorbar(time, gas_mass,   label='gas')
#axes1.errorbar(time, ole1_mass,  label='ole1')
#axes1.errorbar(time, alk1_mass,  label='alk1')
#axes1.errorbar(time, aro1_mass,  label='aro1')
#axes1.errorbar(time, aro2_mass,  label='aro2')
#axes1.errorbar(time, api1_mass,  label='api1')
#axes1.errorbar(time, api2_mass,  label='api2')
#axes1.errorbar(time, lim1_mass,  label='lim1')
#axes1.errorbar(time, lim2_mass,  label='lim2')
axes1.errorbar(time, total_mass, label='total')

axes1.set_xlabel(r"time / h")

axes1.set_ylabel(r"conc. / $\rm kg\ m^{-3} $")
#axes1.set_ylabel(r"ole1 mass conc. / $\rm kg\ $")
#axes1.set_xticks(numpy.arange(0,25,1))
#axes1.set_yticks(numpy.arange(0,5.0E-7,1.0e-7))
#axes2.set_yticks(numpy.arange(0,4.0e-8,1.0e-8))
axes1.legend(loc='lower center', bbox_to_anchor=(1.3, -0.15))
#axes2.legend(loc='lower center', bbox_to_anchor=(1.4, 0.15))
#axes3.legend(loc='lower center', bbox_to_anchor=(1.0, 1.05))
axes1.grid(True)

out_filename = "out/urban_plume_mb.pdf"
print("Writing %s" % out_filename)
figure.savefig(out_filename)

