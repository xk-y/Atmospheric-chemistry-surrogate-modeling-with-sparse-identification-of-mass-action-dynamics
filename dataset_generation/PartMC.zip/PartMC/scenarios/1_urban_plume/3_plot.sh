#!/bin/sh

# exit on error
set -e
# turn on command echoing
set -v

# The data should have already been processed by ./2_process.sh



#./plot_aero_diam_ole1_dist.py
#./plot_aero_diam_bc_dist.py
#./plot_aero_diam_sc_dist.py
#./plot_aero_entropy.py
./plot_aero_total.py
#./plot_aerosol_total.py
./plot_mb.py
./plot_gas.py
./plot_mb1.py

# Now view the out/*.pdf files
