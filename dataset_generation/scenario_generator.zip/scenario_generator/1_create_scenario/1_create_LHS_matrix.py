# %% Load necessary libraries
import numpy as np
import pandas as pd
import pyDOE
import os
import shutil

# https://codeday.me/bug/20170427/11215.html 
def find_nearest(array,value):
    idx = (np.abs(array-value)).argmin()
    return array[idx]



def DOY_lat_temp(DOY, latitude, df): 
    df_DOY = df.loc[df["DOY"]==DOY]
    near_lat = find_nearest(np.asarray(list(set(df_DOY.index))),latitude)
    max_temp = df_DOY.loc[near_lat]["max"]
    min_temp = df_DOY.loc[near_lat]["min"]
    #print("DOY is:", DOY)
    #print("Latitude is:", latitude)
    print("nearest latitude is:",near_lat)
    #print("max temp is:", max_temp)
    #print("min temp is:", min_temp)
    return min_temp, max_temp


"""
def max_min_temp(latitude, doy,df):
    DOY_array = np.array([31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334, 365])
    month = (np.abs(DOY_array-doy)).argmin()+1
    nearest_latitude = find_nearest(df.index, latitude)
    min_temp = df.loc[nearest_latitude][str(month)+"_min"]
    max_temp = df.loc[nearest_latitude][str(month)+"_max"]
    print("The nearest latitude is:", "%.3f" % nearest_latitude)
    print("The nearest month is:", month)
    #print("min_temp:", min_temp)
    #print("max_temp:", max_temp)
    
    return min_temp, max_temp 
"""

df = pd.read_pickle('../../ref/doy_lat_temp/temp_max_min.pkl')

# %% Define the min and max for each variable
# Define the scenarios
#scenarios = int(input("How many scenarios?\n"))
scenarios = 6000
#print("The number of scenarios is:", scenarios)
## Environmental variable
# 1) RH   
RH_min = 0.4; RH_max = 0.999;  #0
# 2) Latitude
Latitude_min = -89.999; Latitude_max = 89.999; #1
# 3) Day of Year 
DOY_min = 1; DOY_max = 365; #2
# 4) Temp
Temp_min = 0; Temp_max = 1; #3
# 5) Restart time stamp 
restart_time_stamp_min = 1; restart_time_stamp_max = 25; #39
# 6) Pressure
pres_min = 9e4; pres_max = 1.1e5 #No.263
# Dilution rate
# To be added
# Mixing height
# To be added
##initial
# Gas init
NO_init_min = 0.90; NO_init_max = 1.10; # No.189
NO2_init_min = 0.90; NO2_init_max = 1.10;
NO3_init_min = 0.90; NO3_init_max = 1.10;
N2O5_init_min = 0.90; N2O5_init_max = 1.10;
HONO_init_min = 0.90; HONO_init_max = 1.10;
HNO3_init_min = 0.90; HNO3_init_max = 1.10;
HNO4_init_min = 0.90; HNO4_init_max = 1.10;
O3_init_min = 0.90; O3_init_max = 1.10;
O1D_init_min = 0.90; O1D_init_max = 1.10;
O3P_init_min = 0.90; O3P_init_max = 1.10;
OH_init_min = 0.90; OH_init_max = 1.10;
HO2_init_min = 0.90; HO2_init_max = 1.10;
H2O2_init_min = 0.90; H2O2_init_max = 1.10;
CO_init_min = 0.90; CO_init_max = 1.10;
SO2_init_min = 0.90; SO2_init_max = 1.10;
H2SO4_init_min = 0.90; H2SO4_init_max = 1.10;
NH3_init_min = 0.90; NH3_init_max = 1.10;
HCL_init_min = 0.90; HCL_init_max = 1.10;
CH4_init_min = 0.90; CH4_init_max = 1.10;
C2H6_init_min = 0.90; C2H6_init_max = 1.10;
CH3O2_init_min = 0.90; CH3O2_init_max = 1.10;
ETHP_init_min = 0.90; ETHP_init_max = 1.10;
HCHO_init_min = 0.90; HCHO_init_max = 1.10;
CH3OH_init_min = 0.90; CH3OH_init_max = 1.10;
CH3OOH_init_min = 0.90; CH3OOH_init_max = 1.10;
ETHOOH_init_min = 0.90; ETHOOH_init_max = 1.10;
ALD2_init_min = 0.90; ALD2_init_max = 1.10;
HCOOH_init_min = 0.90; HCOOH_init_max = 1.10;
PAR_init_min = 0.90; PAR_init_max = 1.10;
AONE_init_min = 0.90; AONE_init_max = 1.10;
MGLY_init_min = 0.90; MGLY_init_max = 1.10;
ETH_init_min = 0.90; ETH_init_max = 1.10;
OLET_init_min = 0.90; OLET_init_max = 1.10;
OLEI_init_min = 0.90; OLEI_init_max = 1.10;
TOL_init_min = 0.90; TOL_init_max = 1.10;
XYL_init_min = 0.90; XYL_init_max = 1.10;
CRES_init_min = 0.90; CRES_init_max = 1.10;
TO2_init_min = 0.90; TO2_init_max = 1.10;
CRO_init_min = 0.90; CRO_init_max = 1.10;
OPEN_init_min = 0.90; OPEN_init_max = 1.10;
ONIT_init_min = 0.90; ONIT_init_max = 1.10;
PAN_init_min = 0.90; PAN_init_max = 1.10;
RCOOH_init_min = 0.90; RCOOH_init_max = 1.10;
ROOH_init_min = 0.90; ROOH_init_max = 1.10;
C2O3_init_min = 0.90; C2O3_init_max = 1.10;
RO2_init_min = 0.90; RO2_init_max = 1.10;
ANO2_init_min = 0.90; ANO2_init_max = 1.10;
NAP_init_min = 0.90; NAP_init_max = 1.10;
ARO1_init_min = 0.90; ARO1_init_max = 0;
ARO2_init_min = 0.90; ARO2_init_max = 0;
ALK1_init_min = 0.90; ALK1_init_max = 0;
OLE1_init_min = 0.90; OLE1_init_max = 0;
XO2_init_min = 0.90; XO2_init_max = 1.10;
XPAR_init_min = 0.90; XPAR_init_max = 1.10;
ISOP_init_min = 0.90; ISOP_init_max = 1.10;
API_init_min = 0.90; API_init_max = 0;
LIM_init_min = 0.90; LIM_init_max = 0;
API1_init_min = 0.90; API1_init_max = 0;
API2_init_min = 0.90; API2_init_max = 0;
LIM1_init_min = 0.90; LIM1_init_max = 0;
LIM2_init_min = 0.90; LIM2_init_max = 0;
ISOPRD_init_min = 0.90; ISOPRD_init_max = 1.10;
ISOPP_init_min = 0.90; ISOPP_init_max = 1.10;
ISOPN_init_min = 0.90; ISOPN_init_max = 1.10;
ISOPO2_init_min = 0.90; ISOPO2_init_max = 1.10;
DMS_init_min = 0.90; DMS_init_max = 1.10;
MSA_init_min = 0.90; MSA_init_max = 1.10;
DMSO_init_min = 0.90; DMSO_init_max = 1.10;
DMSO2_init_min = 0.90; DMSO2_init_max = 1.10;
CH3SO2H_init_min = 0.90; CH3SO2H_init_max = 1.10;
CH3SCH2OO_init_min = 0.90; CH3SCH2OO_init_max = 1.10;
CH3SO2_init_min = 0.90; CH3SO2_init_max = 1.10;
CH3SO3_init_min = 0.90; CH3SO3_init_max = 1.10;
CH3SO2OO_init_min = 0.90; CH3SO2OO_init_max = 1.10;# No.262


## Emission
# Gas phase emissions
#so2 is No.23 (starting from 0)
SO2_emit_min = 0.90; SO2_emit_max = 1.10; SO2_phase_min = 0; SO2_phase_max = 6.283185307;
NO2_emit_min = 0.90; NO2_emit_max = 1.10; NO2_phase_min = 0; NO2_phase_max = 6.283185307;
NO_emit_min = 0.90; NO_emit_max = 1.10; NO_phase_min = 0; NO_phase_max = 6.283185307;
NH3_emit_min = 0.90; NH3_emit_max = 1.10; NH3_phase_min = 0; NH3_phase_max = 6.283185307;
CO_emit_min = 0.90; CO_emit_max = 1.10; CO_phase_min = 0; CO_phase_max = 6.283185307;
DMS_emit_min = 0.90; DMS_emit_max = 1.10; DMS_phase_min = 0; DMS_phase_max = 6.283185307;
C2H5OH_emit_min = 0.90; C2H5OH_emit_max = 1.10; C2H5OH_phase_min = 0; C2H5OH_phase_max = 6.283185307;
CH4_emit_min = 0.90; CH4_emit_max = 1.10; CH4_phase_min = 0; CH4_phase_max = 6.283185307;
CH3COCH3_emit_min = 0.90; CH3COCH3_emit_max = 1.10; CH3COCH3_phase_min = 0; CH3COCH3_phase_max = 6.283185307;
IPROPOL_emit_min = 0.90; IPROPOL_emit_max = 1.10; IPROPOL_phase_min = 0; IPROPOL_phase_max = 6.283185307;
CH3OH_emit_min = 0.90; CH3OH_emit_max = 1.10; CH3OH_phase_min = 0; CH3OH_phase_max = 6.283185307;
IC5H12_emit_min = 0.90; IC5H12_emit_max = 1.10; IC5H12_phase_min = 0; IC5H12_phase_max = 6.283185307;
C3H8_emit_min = 0.90; C3H8_emit_max = 1.10; C3H8_phase_min = 0; C3H8_phase_max = 6.283185307;
OXYL_emit_min = 0.90; OXYL_emit_max = 1.10; OXYL_phase_min = 0; OXYL_phase_max = 6.283185307;
NC4H10_emit_min = 0.90; NC4H10_emit_max = 1.10; NC4H10_phase_min = 0; NC4H10_phase_max = 6.283185307;
C2H4_emit_min = 0.90; C2H4_emit_max = 1.10; C2H4_phase_min = 0; C2H4_phase_max = 6.283185307;
BUOX2ETOH_emit_min = 0.90; BUOX2ETOH_emit_max = 1.10; BUOX2ETOH_phase_min = 0; BUOX2ETOH_phase_max = 6.283185307;
IC4H10_emit_min = 0.90; IC4H10_emit_max = 1.10; IC4H10_phase_min = 0; IC4H10_phase_max = 6.283185307;
HCHO_emit_min = 0.90; HCHO_emit_max = 1.10; HCHO_phase_min = 0; HCHO_phase_max = 6.283185307;
NC6H14_emit_min = 0.90; NC6H14_emit_max = 1.10; NC6H14_phase_min = 0; NC6H14_phase_max = 6.283185307;
M2PE_emit_min = 0.90; M2PE_emit_max = 1.10; M2PE_phase_min = 0; M2PE_phase_max = 6.283185307;
MEK_emit_min = 0.90; MEK_emit_max = 1.10; MEK_phase_min = 0; MEK_phase_max = 6.283185307;
LIMONENE_emit_min = 0.90; LIMONENE_emit_max = 1.10; LIMONENE_phase_min = 0; LIMONENE_phase_max = 6.283185307;
NC5H12_emit_min = 0.90; NC5H12_emit_max = 1.10; NC5H12_phase_min = 0; NC5H12_phase_max = 6.283185307;
C3H6_emit_min = 0.90; C3H6_emit_max = 1.10; C3H6_phase_min = 0; C3H6_phase_max = 6.283185307;
C2H2_emit_min = 0.90; C2H2_emit_max = 1.10; C2H2_phase_min = 0; C2H2_phase_max = 6.283185307;
M3PE_emit_min = 0.90; M3PE_emit_max = 1.10; M3PE_phase_min = 0; M3PE_phase_max = 6.283185307;
NC7H16_emit_min = 0.90; NC7H16_emit_max = 1.10; NC7H16_phase_min = 0; NC7H16_phase_max = 6.283185307;
CH3CHO_emit_min = 0.90; CH3CHO_emit_max = 1.10; CH3CHO_phase_min = 0; CH3CHO_phase_max = 6.283185307;
IPROACET_emit_min = 0.90; IPROACET_emit_max = 1.10; IPROACET_phase_min = 0; IPROACET_phase_max = 6.283185307;
CHEX_emit_min = 0.90; CHEX_emit_max = 1.10; CHEX_phase_min = 0; CHEX_phase_max = 6.283185307;
NPROACET_emit_min = 0.90; NPROACET_emit_max = 1.10; NPROACET_phase_min = 0; NPROACET_phase_max = 6.283185307;
CH3CCL3_emit_min = 0.90; CH3CCL3_emit_max = 1.10; CH3CCL3_phase_min = 0; CH3CCL3_phase_max = 6.283185307;
CH3OCH3_emit_min = 0.90; CH3OCH3_emit_max = 1.10; CH3OCH3_phase_min = 0; CH3OCH3_phase_max = 6.283185307;
ME2BUT2ENE_emit_min = 0.90; ME2BUT2ENE_emit_max = 1.10; ME2BUT2ENE_phase_min = 0; ME2BUT2ENE_phase_max = 6.283185307;
NBUTACET_emit_min = 0.90; NBUTACET_emit_max = 1.10; NBUTACET_phase_min = 0; NBUTACET_phase_max = 6.283185307;
M23C4_emit_min = 0.90; M23C4_emit_max = 1.10; M23C4_phase_min = 0; M23C4_phase_max = 6.283185307;
C2H6_emit_min = 0.90; C2H6_emit_max = 1.10; C2H6_phase_min = 0; C2H6_phase_max = 6.283185307;
C4H6_emit_min = 0.90; C4H6_emit_max = 1.10; C4H6_phase_min = 0; C4H6_phase_max = 6.283185307;
MIBK_emit_min = 0.90; MIBK_emit_max = 1.10; MIBK_phase_min = 0; MIBK_phase_max = 6.283185307;
ETHACET_emit_min = 0.90; ETHACET_emit_max = 1.10; ETHACET_phase_min = 0; ETHACET_phase_max = 6.283185307;
PENT1ENE_emit_min = 0.90; PENT1ENE_emit_max = 1.10; PENT1ENE_phase_min = 0; PENT1ENE_phase_max = 6.283185307;
BUT1ENE_emit_min = 0.90; BUT1ENE_emit_max = 1.10; BUT1ENE_phase_min = 0; BUT1ENE_phase_max = 6.283185307;
CH3CO2H_emit_min = 0.90; CH3CO2H_emit_max = 1.10; CH3CO2H_phase_min = 0; CH3CO2H_phase_max = 6.283185307;
M2HEX_emit_min = 0.90; M2HEX_emit_max = 1.10; M2HEX_phase_min = 0; M2HEX_phase_max = 6.283185307;
BOX2PROL_emit_min = 0.90; BOX2PROL_emit_max = 1.10; BOX2PROL_phase_min = 0; BOX2PROL_phase_max = 6.283185307;
ME2BUT1ENE_emit_min = 0.90; ME2BUT1ENE_emit_max = 1.10; ME2BUT1ENE_phase_min = 0; ME2BUT1ENE_phase_max = 6.283185307;
ACR_emit_min = 0.90; ACR_emit_max = 1.10; ACR_phase_min = 0; ACR_phase_max = 6.283185307;
CBUT2ENE_emit_min = 0.90; CBUT2ENE_emit_max = 1.10; CBUT2ENE_phase_min = 0; CBUT2ENE_phase_max = 6.283185307;
MEPROPENE_emit_min = 0.90; MEPROPENE_emit_max = 1.10; MEPROPENE_phase_min = 0; MEPROPENE_phase_max = 6.283185307;
HEX1ENE_emit_min = 0.90; HEX1ENE_emit_max = 1.10; HEX1ENE_phase_min = 0; HEX1ENE_phase_max = 6.283185307;
C2H5CHO_emit_min = 0.90; C2H5CHO_emit_max = 1.10; C2H5CHO_phase_min = 0; C2H5CHO_phase_max = 6.283185307;
C4ALDB_emit_min = 0.90; C4ALDB_emit_max = 1.10; C4ALDB_phase_min = 0; C4ALDB_phase_max = 6.283185307;
BUT2OL_emit_min = 0.90; BUT2OL_emit_max = 1.10; BUT2OL_phase_min = 0; BUT2OL_phase_max = 6.283185307;
M3HEX_emit_min = 0.90; M3HEX_emit_max = 1.10; M3HEX_phase_min = 0; M3HEX_phase_max = 6.283185307;
NC10H22_emit_min = 0.90; NC10H22_emit_max = 1.10; NC10H22_phase_min = 0; NC10H22_phase_max = 6.283185307;
NC11H24_emit_min = 0.90; NC11H24_emit_max = 1.10; NC11H24_phase_min = 0; NC11H24_phase_max = 6.283185307;
NBUTOL_emit_min = 0.90; NBUTOL_emit_max = 1.10; NBUTOL_phase_min = 0; NBUTOL_phase_max = 6.283185307;
NC12H26_emit_min = 0.90; NC12H26_emit_max = 1.10; NC12H26_phase_min = 0; NC12H26_phase_max = 6.283185307;
DIETETHER_emit_min = 0.90; DIETETHER_emit_max = 1.10; DIETETHER_phase_min = 0; DIETETHER_phase_max = 6.283185307;
M22C4_emit_min = 0.90; M22C4_emit_max = 1.10; M22C4_phase_min = 0; M22C4_phase_max = 6.283185307;
NC8H18_emit_min = 0.90; NC8H18_emit_max = 1.10; NC8H18_phase_min = 0; NC8H18_phase_max = 6.283185307;
MIBKAOH_emit_min = 0.90; MIBKAOH_emit_max = 1.10; MIBKAOH_phase_min = 0; MIBKAOH_phase_max = 6.283185307;
C3H7CHO_emit_min = 0.90; C3H7CHO_emit_max = 1.10; C3H7CHO_phase_min = 0; C3H7CHO_phase_max = 6.283185307;
C5H11CHO_emit_min = 0.90; C5H11CHO_emit_max = 1.10; C5H11CHO_phase_min = 0; C5H11CHO_phase_max = 6.283185307;
C6H13CHO_emit_min = 0.90; C6H13CHO_emit_max = 1.10; C6H13CHO_phase_min = 0; C6H13CHO_phase_max = 6.283185307;
NPROPOL_emit_min = 0.90; NPROPOL_emit_max = 1.10; NPROPOL_phase_min = 0; NPROPOL_phase_max = 6.283185307;
NC9H20_emit_min = 0.90; NC9H20_emit_max = 1.10; NC9H20_phase_min = 0; NC9H20_phase_max = 6.283185307;
BIACET_emit_min = 0.90; BIACET_emit_max = 1.10; BIACET_phase_min = 0; BIACET_phase_max = 6.283185307;
APINENE_emit_min = 0.90; APINENE_emit_max = 1.10; APINENE_phase_min = 0; APINENE_phase_max = 6.283185307;
MACR_emit_min = 0.90; MACR_emit_max = 1.10; MACR_phase_min = 0; MACR_phase_max = 6.283185307;
EGLYOX_emit_min = 0.90; EGLYOX_emit_max = 1.10; EGLYOX_phase_min = 0; EGLYOX_phase_max = 6.283185307;
PROPACID_emit_min = 0.90; PROPACID_emit_max = 1.10; PROPACID_phase_min = 0; PROPACID_phase_max = 6.283185307;
C4H9CHO_emit_min = 0.90; C4H9CHO_emit_max = 1.10; C4H9CHO_phase_min = 0; C4H9CHO_phase_max = 6.283185307;
TBUTOL_emit_min = 0.90; TBUTOL_emit_max = 1.10; TBUTOL_phase_min = 0; TBUTOL_phase_max = 6.283185307;
MO2EOL_emit_min = 0.90; MO2EOL_emit_max = 1.10; MO2EOL_phase_min = 0; MO2EOL_phase_max = 6.283185307;
METHCOACET_emit_min = 0.90; METHCOACET_emit_max = 1.10; METHCOACET_phase_min = 0; METHCOACET_phase_max = 6.283185307;
BUTACID_emit_min = 0.90; BUTACID_emit_max = 1.10; BUTACID_phase_min = 0; BUTACID_phase_max = 6.283185307;
CH3CH2CL_emit_min = 0.90; CH3CH2CL_emit_max = 1.10; CH3CH2CL_phase_min = 0; CH3CH2CL_phase_max = 6.283185307;
TBUACET_emit_min = 0.90; TBUACET_emit_max = 1.10; TBUACET_phase_min = 0; TBUACET_phase_max = 6.283185307;
CH3OCHO_emit_min = 0.90; CH3OCHO_emit_max = 1.10; CH3OCHO_phase_min = 0; CH3OCHO_phase_max = 6.283185307;
NEOP_emit_min = 0.90; NEOP_emit_max = 1.10; NEOP_phase_min = 0; NEOP_phase_max = 6.283185307;
DMM_emit_min = 0.90; DMM_emit_max = 1.10; DMM_phase_min = 0; DMM_phase_max = 6.283185307;
MPRK_emit_min = 0.90; MPRK_emit_max = 1.10; MPRK_phase_min = 0; MPRK_phase_max = 6.283185307;
C3ME3CO2H_emit_min = 0.90; C3ME3CO2H_emit_max = 1.10; C3ME3CO2H_phase_min = 0; C3ME3CO2H_phase_max = 6.283185307;
IBUTACID_emit_min = 0.90; IBUTACID_emit_max = 1.10; IBUTACID_phase_min = 0; IBUTACID_phase_max = 6.283185307;
PENTACID_emit_min = 0.90; PENTACID_emit_max = 1.10; PENTACID_phase_min = 0; PENTACID_phase_max = 6.283185307;
C6H13CO2H_emit_min = 0.90; C6H13CO2H_emit_max = 1.10; C6H13CO2H_phase_min = 0; C6H13CO2H_phase_max = 6.283185307;
M2PEBOH_emit_min = 0.90; M2PEBOH_emit_max = 1.10; M2PEBOH_phase_min = 0; M2PEBOH_phase_max = 6.283185307;
CH3CL_emit_min = 0.90; CH3CL_emit_max = 1.10; CH3CL_phase_min = 0; CH3CL_phase_max = 6.283185307;
CO24C5_emit_min = 0.90; CO24C5_emit_max = 1.10; CO24C5_phase_min = 0; CO24C5_phase_max = 6.283185307;
DMS_emit_min = 0.90; DMS_emit_max = 1.10; DMS_phase_min = 0; DMS_phase_max = 6.283185307;
ETBE_emit_min = 0.90; ETBE_emit_max = 1.10; ETBE_phase_min = 0; ETBE_phase_max = 6.283185307;
CH3BR_emit_min = 0.90; CH3BR_emit_max = 1.10; CH3BR_phase_min = 0; CH3BR_phase_max = 6.283185307;
HEXAOH_emit_min = 0.90; HEXAOH_emit_max = 1.10; HEXAOH_phase_min = 0; HEXAOH_phase_max = 6.283185307;
HEX2ONE_emit_min = 0.90; HEX2ONE_emit_max = 1.10; HEX2ONE_phase_min = 0; HEX2ONE_phase_max = 6.283185307;
CHCL2CH3_emit_min = 0.90; CHCL2CH3_emit_max = 1.10; CHCL2CH3_phase_min = 0; CHCL2CH3_phase_max = 6.283185307;
DMSO2_emit_min = 0.90; DMSO2_emit_max = 1.10; DMSO2_phase_min = 0; DMSO2_phase_max = 6.283185307;
DIEK_emit_min = 0.90; DIEK_emit_max = 1.10; DIEK_phase_min = 0; DIEK_phase_max = 6.283185307;
PEBOH_emit_min = 0.90; PEBOH_emit_max = 1.10; PEBOH_phase_min = 0; PEBOH_phase_max = 6.283185307;
HEX3ONE_emit_min = 0.90; HEX3ONE_emit_max = 1.10; HEX3ONE_phase_min = 0; HEX3ONE_phase_max = 6.283185307;
TOLUENE_emit_min = 0.90; TOLUENE_emit_max = 1.10; TOLUENE_phase_min = 0; TOLUENE_phase_max = 6.283185307;
PROPGLY_emit_min = 0.90; PROPGLY_emit_max = 1.10; PROPGLY_phase_min = 0; PROPGLY_phase_max = 6.283185307;
BENZENE_emit_min = 0.90; BENZENE_emit_max = 1.10; BENZENE_phase_min = 0; BENZENE_phase_max = 6.283185307;
MXYL_emit_min = 0.90; MXYL_emit_max = 1.10; MXYL_phase_min = 0; MXYL_phase_max = 6.283185307;
ETHGLY_emit_min = 0.90; ETHGLY_emit_max = 1.10; ETHGLY_phase_min = 0; ETHGLY_phase_max = 6.283185307;
TPENT2ENE_emit_min = 0.90; TPENT2ENE_emit_max = 1.10; TPENT2ENE_phase_min = 0; TPENT2ENE_phase_max = 6.283185307;
CPENT2ENE_emit_min = 0.90; CPENT2ENE_emit_max = 1.10; CPENT2ENE_phase_min = 0; CPENT2ENE_phase_max = 6.283185307;
TRICLETH_emit_min = 0.90; TRICLETH_emit_max = 1.10; TRICLETH_phase_min = 0; TRICLETH_phase_max = 6.283185307;
EBENZ_emit_min = 0.90; EBENZ_emit_max = 1.10; EBENZ_phase_min = 0; EBENZ_phase_max = 6.283185307;
OXYL_emit_min = 0.90; OXYL_emit_max = 1.10; OXYL_phase_min = 0; OXYL_phase_max = 6.283185307;
TM124B_emit_min = 0.90; TM124B_emit_max = 1.10; TM124B_phase_min = 0; TM124B_phase_max = 6.283185307;
STYRENE_emit_min = 0.90; STYRENE_emit_max = 1.10; STYRENE_phase_min = 0; STYRENE_phase_max = 6.283185307;
MGLYOX_emit_min = 0.90; MGLYOX_emit_max = 1.10; MGLYOX_phase_min = 0; MGLYOX_phase_max = 6.283185307;
GLYOX_emit_min = 0.90; GLYOX_emit_max = 1.10; GLYOX_phase_min = 0; GLYOX_phase_max = 6.283185307;
PHENOL_emit_min = 0.90; PHENOL_emit_max = 1.10; PHENOL_phase_min = 0; PHENOL_phase_max = 6.283185307;
PR2OHMOX_emit_min = 0.90; PR2OHMOX_emit_max = 1.10; PR2OHMOX_phase_min = 0; PR2OHMOX_phase_max = 6.283185307;
METHTOL_emit_min = 0.90; METHTOL_emit_max = 1.10; METHTOL_phase_min = 0; METHTOL_phase_max = 6.283185307;
OETHTOL_emit_min = 0.90; OETHTOL_emit_max = 1.10; OETHTOL_phase_min = 0; OETHTOL_phase_max = 6.283185307;
THEX2ENE_emit_min = 0.90; THEX2ENE_emit_max = 1.10; THEX2ENE_phase_min = 0; THEX2ENE_phase_max = 6.283185307;
HCOOH_emit_min = 0.90; HCOOH_emit_max = 1.10; HCOOH_phase_min = 0; HCOOH_phase_max = 6.283185307;
TM135B_emit_min = 0.90; TM135B_emit_max = 1.10; TM135B_phase_min = 0; TM135B_phase_max = 6.283185307;
IBUTOL_emit_min = 0.90; IBUTOL_emit_max = 1.10; IBUTOL_phase_min = 0; IBUTOL_phase_max = 6.283185307;
CYHEXONE_emit_min = 0.90; CYHEXONE_emit_max = 1.10; CYHEXONE_phase_min = 0; CYHEXONE_phase_max = 6.283185307;
BENZAL_emit_min = 0.90; BENZAL_emit_max = 1.10; BENZAL_phase_min = 0; BENZAL_phase_max = 6.283185307;
CHCL3_emit_min = 0.90; CHCL3_emit_max = 1.10; CHCL3_phase_min = 0; CHCL3_phase_max = 6.283185307;
PBENZ_emit_min = 0.90; PBENZ_emit_max = 1.10; PBENZ_phase_min = 0; PBENZ_phase_max = 6.283185307;
IPBENZ_emit_min = 0.90; IPBENZ_emit_max = 1.10; IPBENZ_phase_min = 0; IPBENZ_phase_max = 6.283185307;
ME3BUT1ENE_emit_min = 0.90; ME3BUT1ENE_emit_max = 1.10; ME3BUT1ENE_phase_min = 0; ME3BUT1ENE_phase_max = 6.283185307;
PETHTOL_emit_min = 0.90; PETHTOL_emit_max = 1.10; PETHTOL_phase_min = 0; PETHTOL_phase_max = 6.283185307;
METHACET_emit_min = 0.90; METHACET_emit_max = 1.10; METHACET_phase_min = 0; METHACET_phase_max = 6.283185307;
CATECHOL_emit_min = 0.90; CATECHOL_emit_max = 1.10; CATECHOL_phase_min = 0; CATECHOL_phase_max = 6.283185307;
OXYLAL_emit_min = 0.90; OXYLAL_emit_max = 1.10; OXYLAL_phase_min = 0; OXYLAL_phase_max = 6.283185307;
CYHEXOL_emit_min = 0.90; CYHEXOL_emit_max = 1.10; CYHEXOL_phase_min = 0; CYHEXOL_phase_max = 6.283185307;
CDICLETH_emit_min = 0.90; CDICLETH_emit_max = 1.10; CDICLETH_phase_min = 0; CDICLETH_phase_max = 6.283185307;
TDICLETH_emit_min = 0.90; TDICLETH_emit_max = 1.10; TDICLETH_phase_min = 0; TDICLETH_phase_max = 6.283185307;
CRESOL_emit_min = 0.90; CRESOL_emit_max = 1.10; CRESOL_phase_min = 0; CRESOL_phase_max = 6.283185307;
C6H5CH2OH_emit_min = 0.90; C6H5CH2OH_emit_max = 1.10; C6H5CH2OH_phase_min = 0; C6H5CH2OH_phase_max = 6.283185307;
EOX2EOL_emit_min = 0.90; EOX2EOL_emit_max = 1.10; EOX2EOL_phase_min = 0; EOX2EOL_phase_max = 6.283185307;
PXYL_emit_min = 0.90; PXYL_emit_max = 1.10; PXYL_phase_min = 0; PXYL_phase_max = 6.283185307;
MALANHY_emit_min = 0.90; MALANHY_emit_max = 1.10; MALANHY_phase_min = 0; MALANHY_phase_max = 6.283185307;
ACO2H_emit_min = 0.90; ACO2H_emit_max = 1.10; ACO2H_phase_min = 0; ACO2H_phase_max = 6.283185307;
ETHOX_emit_min = 0.90; ETHOX_emit_max = 1.10; ETHOX_phase_min = 0; ETHOX_phase_max = 6.283185307;
MTBE_emit_min = 0.90; MTBE_emit_max = 1.10; MTBE_phase_min = 0; MTBE_phase_max = 6.283185307;
VINCL_emit_min = 0.90; VINCL_emit_max = 1.10; VINCL_phase_min = 0; VINCL_phase_max = 6.283185307;
DIBRET_emit_min = 0.90; DIBRET_emit_max = 1.10; DIBRET_phase_min = 0; DIBRET_phase_max = 6.283185307;
CH3CCL3_emit_min = 0.90; CH3CCL3_emit_max = 1.10; CH3CCL3_phase_min = 0; CH3CCL3_phase_max = 6.283185307;
MXYLAL_emit_min = 0.90; MXYLAL_emit_max = 1.10; MXYLAL_phase_min = 0; MXYLAL_phase_max = 6.283185307;
PHCOOH_emit_min = 0.90; PHCOOH_emit_max = 1.10; PHCOOH_phase_min = 0; PHCOOH_phase_max = 6.283185307;
BPINENE_emit_min = 0.90; BPINENE_emit_max = 1.10; BPINENE_phase_min = 0; BPINENE_phase_max = 6.283185307;
C3ME3CHO_emit_min = 0.90; C3ME3CHO_emit_max = 1.10; C3ME3CHO_phase_min = 0; C3ME3CHO_phase_max = 6.283185307;
PHCOME_emit_min = 0.90; PHCOME_emit_max = 1.10; PHCOME_phase_min = 0; PHCOME_phase_max = 6.283185307;
BUT2OLO_emit_min = 0.90; BUT2OLO_emit_max = 1.10; BUT2OLO_phase_min = 0; BUT2OLO_phase_max = 6.283185307;
BCARY_emit_min = 0.90; BCARY_emit_max = 1.10; BCARY_phase_min = 0; BCARY_phase_max = 6.283185307;
EBENZOL_emit_min = 0.90; EBENZOL_emit_max = 1.10; EBENZOL_phase_min = 0; EBENZOL_phase_max = 6.283185307;
M3F_emit_min = 0.90; M3F_emit_max = 1.10; M3F_phase_min = 0; M3F_phase_max = 6.283185307;
LIMONENE_emit_min = 0.90; LIMONENE_emit_max = 1.10; LIMONENE_phase_min = 0; LIMONENE_phase_max = 6.283185307;
PHIC3OH_emit_min = 0.90; PHIC3OH_emit_max = 1.10; PHIC3OH_phase_min = 0; PHIC3OH_phase_max = 6.283185307;
CCL2CH2_emit_min = 0.90; CCL2CH2_emit_max = 1.10; CCL2CH2_phase_min = 0; CCL2CH2_phase_max = 6.283185307;
CL12PROP_emit_min = 0.90; CL12PROP_emit_max = 1.10; CL12PROP_phase_min = 0; CL12PROP_phase_max = 6.283185307;
TM123BCHO_emit_min = 0.90; TM123BCHO_emit_max = 1.10; TM123BCHO_phase_min = 0; TM123BCHO_phase_max = 6.283185307;
DNCRES_emit_min = 0.90; DNCRES_emit_max = 1.10; DNCRES_phase_min = 0; DNCRES_phase_max = 6.283185307;
ALLYLOH_emit_min = 0.90; ALLYLOH_emit_max = 1.10; ALLYLOH_phase_min = 0; ALLYLOH_phase_max = 6.283185307;
DNPHEN_emit_min = 0.90; DNPHEN_emit_max = 1.10; DNPHEN_phase_min = 0; DNPHEN_phase_max = 6.283185307;
BUT2CHO_emit_min = 0.90; BUT2CHO_emit_max = 1.10; BUT2CHO_phase_min = 0; BUT2CHO_phase_max = 6.283185307;
HOC6H4NO2_emit_min = 0.90; HOC6H4NO2_emit_max = 1.10; HOC6H4NO2_phase_min = 0; HOC6H4NO2_phase_max = 6.283185307;

# HOC6H4NO2 is No.188

# Carbonaceous Aerosol Emissions
# 1) Dg
Dg_cae_min = 2.5e-08; Dg_cae_max = 2.5e-07; #21
# 2) sigmag
sigmag_cae_min = 1.4; sigmag_cae_max = 2.5; #22
# 3) Ea
Ea_cae_min = 0; Ea_cae_max = 1.6e7; #23
# 4) BC percentage
BC_per_min = 0; BC_per_max = 1; #24

# Sea Salt Emissions
# 1) Dg1
Dg1_sse_min = 1.8e-07; Dg1_sse_max = 7.2e-07; #25
# 2) sigmag1
sigmag1_sse_min = 1.4; sigmag1_sse_max = 2.5; #26
# 3) Ea1
Ea1_sse_min = 0; Ea1_sse_max = 1.69e5; #27
# 4) OC_1 fraction
OC_1_fra_min = 0; OC_1_fra_max = 0.2; #28 
# 4) Dg2
Dg2_sse_min = 1.0e-06; Dg2_sse_max = 6.0e-06; #29
# 5) sigmag2
sigmag2_sse_min = 1.4; sigmag2_sse_max = 2.5; #30
# 6) Ea2
Ea2_sse_min = 0; Ea2_sse_max = 2.38e03; #31
# 7) OC_2 fraction
OC_2_fra_min = 0; OC_2_fra_max = 0.2; #32

# Dust Emissions
# 1) Dg1
Dg1_dust_min = 8.0e-8; Dg1_dust_max = 3.2e-07; #33
# 2) sigmag1
sigmag1_dust_min = 1.4; sigmag1_dust_max = 2.5; #34
# 3) Ea1
Ea1_dust_min = 0; Ea1_dust_max = 5.86e05; #35
# 4) Dg2
Dg2_dust_min = 1.0e-6; Dg2_dust_max = 6.0e-6; #36
# 5) sigmag2
sigmag2_dust_min = 1.4; sigmag2_dust_max = 2.5; #37
# 6) Ea2
Ea2_dust_min = 0; Ea2_dust_max = 2.38e03; #38

# Create Latin Hypercube Sampling matrix and save
lhs_min = np.asarray([RH_min, Latitude_min, DOY_min, Temp_min,  
           Dg_cae_min, sigmag_cae_min, Ea_cae_min, BC_per_min, 
           Dg1_sse_min, sigmag1_sse_min, Ea1_sse_min, OC_1_fra_min,
           Dg2_sse_min, sigmag2_sse_min, Ea2_sse_min, OC_2_fra_min,
           Dg1_dust_min, sigmag1_dust_min, Ea1_dust_min, Dg2_dust_min, sigmag2_dust_min, Ea2_dust_min, 
           restart_time_stamp_min,
           SO2_emit_min,  NO2_emit_min,  NO_emit_min, NH3_emit_min, CO_emit_min, DMS_emit_min, 
           C2H5OH_emit_min, CH4_emit_min, CH3COCH3_emit_min, IPROPOL_emit_min, CH3OH_emit_min, 
           IC5H12_emit_min, C3H8_emit_min, OXYL_emit_min, NC4H10_emit_min, C2H4_emit_min, 
           BUOX2ETOH_emit_min, IC4H10_emit_min, HCHO_emit_min, NC6H14_emit_min, M2PE_emit_min, 
           MEK_emit_min, LIMONENE_emit_min, NC5H12_emit_min, C3H6_emit_min, C2H2_emit_min, 
           M3PE_emit_min, NC7H16_emit_min, CH3CHO_emit_min, IPROACET_emit_min, CHEX_emit_min, 
           NPROACET_emit_min, CH3CCL3_emit_min, CH3OCH3_emit_min, ME2BUT2ENE_emit_min, 
           NBUTACET_emit_min, M23C4_emit_min, C2H6_emit_min, C4H6_emit_min, MIBK_emit_min, 
           ETHACET_emit_min, PENT1ENE_emit_min, BUT1ENE_emit_min, CH3CO2H_emit_min, 
           M2HEX_emit_min, BOX2PROL_emit_min, ME2BUT1ENE_emit_min, ACR_emit_min, 
           CBUT2ENE_emit_min, MEPROPENE_emit_min, HEX1ENE_emit_min, C2H5CHO_emit_min, 
           C4ALDB_emit_min, BUT2OL_emit_min, M3HEX_emit_min, NC10H22_emit_min, 
           NC11H24_emit_min, NBUTOL_emit_min, NC12H26_emit_min, DIETETHER_emit_min, 
           M22C4_emit_min, NC8H18_emit_min, MIBKAOH_emit_min, C3H7CHO_emit_min, 
           C5H11CHO_emit_min, C6H13CHO_emit_min, NPROPOL_emit_min, NC9H20_emit_min, 
           BIACET_emit_min, APINENE_emit_min, MACR_emit_min, EGLYOX_emit_min, PROPACID_emit_min, 
           C4H9CHO_emit_min, TBUTOL_emit_min, MO2EOL_emit_min, METHCOACET_emit_min, 
           BUTACID_emit_min, CH3CH2CL_emit_min, TBUACET_emit_min, CH3OCHO_emit_min, 
           NEOP_emit_min, DMM_emit_min, MPRK_emit_min, C3ME3CO2H_emit_min, IBUTACID_emit_min, 
           PENTACID_emit_min, C6H13CO2H_emit_min, M2PEBOH_emit_min, CH3CL_emit_min, 
           CO24C5_emit_min, DMS_emit_min, ETBE_emit_min, CH3BR_emit_min, HEXAOH_emit_min, 
           HEX2ONE_emit_min, CHCL2CH3_emit_min, DMSO2_emit_min, DIEK_emit_min, PEBOH_emit_min, 
           HEX3ONE_emit_min, TOLUENE_emit_min, PROPGLY_emit_min, BENZENE_emit_min, MXYL_emit_min, 
           ETHGLY_emit_min, TPENT2ENE_emit_min, CPENT2ENE_emit_min, TRICLETH_emit_min, 
           EBENZ_emit_min, OXYL_emit_min, TM124B_emit_min, STYRENE_emit_min, MGLYOX_emit_min, 
           GLYOX_emit_min, PHENOL_emit_min, PR2OHMOX_emit_min, METHTOL_emit_min, 
           OETHTOL_emit_min, THEX2ENE_emit_min, HCOOH_emit_min, TM135B_emit_min, 
           IBUTOL_emit_min, CYHEXONE_emit_min, BENZAL_emit_min, CHCL3_emit_min, PBENZ_emit_min, 
           IPBENZ_emit_min, ME3BUT1ENE_emit_min, PETHTOL_emit_min, METHACET_emit_min, 
           CATECHOL_emit_min, OXYLAL_emit_min, CYHEXOL_emit_min, CDICLETH_emit_min, 
           TDICLETH_emit_min, CRESOL_emit_min, C6H5CH2OH_emit_min, EOX2EOL_emit_min, 
           PXYL_emit_min, MALANHY_emit_min, ACO2H_emit_min, ETHOX_emit_min, MTBE_emit_min, 
           VINCL_emit_min, DIBRET_emit_min, CH3CCL3_emit_min, MXYLAL_emit_min, PHCOOH_emit_min, 
           BPINENE_emit_min, C3ME3CHO_emit_min, PHCOME_emit_min, BUT2OLO_emit_min, 
           BCARY_emit_min, EBENZOL_emit_min, M3F_emit_min, LIMONENE_emit_min, PHIC3OH_emit_min, 
           CCL2CH2_emit_min, CL12PROP_emit_min, TM123BCHO_emit_min, DNCRES_emit_min, ALLYLOH_emit_min, 
           DNPHEN_emit_min, BUT2CHO_emit_min, HOC6H4NO2_emit_min,
           NO_init_min, NO2_init_min, NO3_init_min, N2O5_init_min, HONO_init_min, 
           HNO3_init_min, HNO4_init_min, O3_init_min, O1D_init_min, O3P_init_min, 
           OH_init_min, HO2_init_min, H2O2_init_min, CO_init_min, SO2_init_min, 
           H2SO4_init_min, NH3_init_min, HCL_init_min, CH4_init_min, C2H6_init_min, 
           CH3O2_init_min, ETHP_init_min, HCHO_init_min, CH3OH_init_min, CH3OOH_init_min, 
           ETHOOH_init_min, ALD2_init_min, HCOOH_init_min, PAR_init_min, AONE_init_min, 
           MGLY_init_min, ETH_init_min, OLET_init_min, OLEI_init_min, TOL_init_min, 
           XYL_init_min, CRES_init_min, TO2_init_min, CRO_init_min, OPEN_init_min, 
           ONIT_init_min, PAN_init_min, RCOOH_init_min, ROOH_init_min, C2O3_init_min, 
           RO2_init_min, ANO2_init_min, NAP_init_min, ARO1_init_min, ARO2_init_min, 
           ALK1_init_min, OLE1_init_min, XO2_init_min, XPAR_init_min, ISOP_init_min,
           API_init_min, LIM_init_min, API1_init_min, API2_init_min, LIM1_init_min, 
           LIM2_init_min, ISOPRD_init_min, ISOPP_init_min, ISOPN_init_min, ISOPO2_init_min, 
           DMS_init_min, MSA_init_min, DMSO_init_min, DMSO2_init_min, CH3SO2H_init_min,
           CH3SCH2OO_init_min, CH3SO2_init_min, CH3SO3_init_min, CH3SO2OO_init_min,
           pres_min,
           SO2_phase_min, NO2_phase_min, NO_phase_min, NH3_phase_min, CO_phase_min, DMS_phase_min, C2H5OH_phase_min, CH4_phase_min, CH3COCH3_phase_min, IPROPOL_phase_min, CH3OH_phase_min, IC5H12_phase_min, C3H8_phase_min, OXYL_phase_min, NC4H10_phase_min, C2H4_phase_min, BUOX2ETOH_phase_min, IC4H10_phase_min, HCHO_phase_min, NC6H14_phase_min, M2PE_phase_min, MEK_phase_min, LIMONENE_phase_min, NC5H12_phase_min, C3H6_phase_min, C2H2_phase_min, M3PE_phase_min, NC7H16_phase_min, CH3CHO_phase_min, IPROACET_phase_min, CHEX_phase_min, NPROACET_phase_min, CH3CCL3_phase_min, CH3OCH3_phase_min, ME2BUT2ENE_phase_min, NBUTACET_phase_min, M23C4_phase_min, C2H6_phase_min, C4H6_phase_min, MIBK_phase_min, ETHACET_phase_min, PENT1ENE_phase_min, BUT1ENE_phase_min, CH3CO2H_phase_min, M2HEX_phase_min, BOX2PROL_phase_min, ME2BUT1ENE_phase_min, ACR_phase_min, CBUT2ENE_phase_min, MEPROPENE_phase_min, HEX1ENE_phase_min, C2H5CHO_phase_min, C4ALDB_phase_min, BUT2OL_phase_min, M3HEX_phase_min, NC10H22_phase_min, NC11H24_phase_min, NBUTOL_phase_min, NC12H26_phase_min, DIETETHER_phase_min, M22C4_phase_min, NC8H18_phase_min, MIBKAOH_phase_min, C3H7CHO_phase_min, C5H11CHO_phase_min, C6H13CHO_phase_min, NPROPOL_phase_min, NC9H20_phase_min, BIACET_phase_min, APINENE_phase_min, MACR_phase_min, EGLYOX_phase_min, PROPACID_phase_min, C4H9CHO_phase_min, TBUTOL_phase_min, MO2EOL_phase_min, METHCOACET_phase_min, BUTACID_phase_min, CH3CH2CL_phase_min, TBUACET_phase_min, CH3OCHO_phase_min, NEOP_phase_min, DMM_phase_min, MPRK_phase_min, C3ME3CO2H_phase_min, IBUTACID_phase_min, PENTACID_phase_min, C6H13CO2H_phase_min, M2PEBOH_phase_min, CH3CL_phase_min, CO24C5_phase_min, DMS_phase_min, ETBE_phase_min, CH3BR_phase_min, HEXAOH_phase_min, HEX2ONE_phase_min, CHCL2CH3_phase_min, DMSO2_phase_min, DIEK_phase_min, PEBOH_phase_min, HEX3ONE_phase_min, TOLUENE_phase_min, PROPGLY_phase_min, BENZENE_phase_min, MXYL_phase_min, ETHGLY_phase_min, TPENT2ENE_phase_min, CPENT2ENE_phase_min, TRICLETH_phase_min, EBENZ_phase_min, OXYL_phase_min, TM124B_phase_min, STYRENE_phase_min, MGLYOX_phase_min, GLYOX_phase_min, PHENOL_phase_min, PR2OHMOX_phase_min, METHTOL_phase_min, OETHTOL_phase_min, THEX2ENE_phase_min, HCOOH_phase_min, TM135B_phase_min, IBUTOL_phase_min, CYHEXONE_phase_min, BENZAL_phase_min, CHCL3_phase_min, PBENZ_phase_min, IPBENZ_phase_min, ME3BUT1ENE_phase_min, PETHTOL_phase_min, METHACET_phase_min, CATECHOL_phase_min, OXYLAL_phase_min, CYHEXOL_phase_min, CDICLETH_phase_min, TDICLETH_phase_min, CRESOL_phase_min, C6H5CH2OH_phase_min, EOX2EOL_phase_min, PXYL_phase_min, MALANHY_phase_min, ACO2H_phase_min, ETHOX_phase_min, MTBE_phase_min, VINCL_phase_min, DIBRET_phase_min, CH3CCL3_phase_min, MXYLAL_phase_min, PHCOOH_phase_min, BPINENE_phase_min, C3ME3CHO_phase_min, PHCOME_phase_min, BUT2OLO_phase_min, BCARY_phase_min, EBENZOL_phase_min, M3F_phase_min, LIMONENE_phase_min, PHIC3OH_phase_min, CCL2CH2_phase_min, CL12PROP_phase_min, TM123BCHO_phase_min, DNCRES_phase_min, ALLYLOH_phase_min, DNPHEN_phase_min, BUT2CHO_phase_min, HOC6H4NO2_phase_min])
lhs_max = np.asarray([RH_max, Latitude_max, DOY_max, Temp_max, 
           Dg_cae_max, sigmag_cae_max, Ea_cae_max, BC_per_max, 
           Dg1_sse_max, sigmag1_sse_max, Ea1_sse_max, OC_1_fra_max,
           Dg2_sse_max, sigmag2_sse_max, Ea2_sse_max, OC_2_fra_max,
           Dg1_dust_max, sigmag1_dust_max, Ea1_dust_max, Dg2_dust_max, sigmag2_dust_max, Ea2_dust_max, 
           restart_time_stamp_max,
           SO2_emit_max,  NO2_emit_max,  NO_emit_max, NH3_emit_max, CO_emit_max, DMS_emit_max, 
           C2H5OH_emit_max, CH4_emit_max, CH3COCH3_emit_max, IPROPOL_emit_max, CH3OH_emit_max, 
           IC5H12_emit_max, C3H8_emit_max, OXYL_emit_max, NC4H10_emit_max, C2H4_emit_max, 
           BUOX2ETOH_emit_max, IC4H10_emit_max, HCHO_emit_max, NC6H14_emit_max, M2PE_emit_max, 
           MEK_emit_max, LIMONENE_emit_max, NC5H12_emit_max, C3H6_emit_max, C2H2_emit_max, 
           M3PE_emit_max, NC7H16_emit_max, CH3CHO_emit_max, IPROACET_emit_max, CHEX_emit_max, 
           NPROACET_emit_max, CH3CCL3_emit_max, CH3OCH3_emit_max, ME2BUT2ENE_emit_max, 
           NBUTACET_emit_max, M23C4_emit_max, C2H6_emit_max, C4H6_emit_max, MIBK_emit_max, 
           ETHACET_emit_max, PENT1ENE_emit_max, BUT1ENE_emit_max, CH3CO2H_emit_max, 
           M2HEX_emit_max, BOX2PROL_emit_max, ME2BUT1ENE_emit_max, ACR_emit_max, 
           CBUT2ENE_emit_max, MEPROPENE_emit_max, HEX1ENE_emit_max, C2H5CHO_emit_max, 
           C4ALDB_emit_max, BUT2OL_emit_max, M3HEX_emit_max, NC10H22_emit_max, 
           NC11H24_emit_max, NBUTOL_emit_max, NC12H26_emit_max, DIETETHER_emit_max, 
           M22C4_emit_max, NC8H18_emit_max, MIBKAOH_emit_max, C3H7CHO_emit_max, 
           C5H11CHO_emit_max, C6H13CHO_emit_max, NPROPOL_emit_max, NC9H20_emit_max, 
           BIACET_emit_max, APINENE_emit_max, MACR_emit_max, EGLYOX_emit_max, PROPACID_emit_max, 
           C4H9CHO_emit_max, TBUTOL_emit_max, MO2EOL_emit_max, METHCOACET_emit_max, 
           BUTACID_emit_max, CH3CH2CL_emit_max, TBUACET_emit_max, CH3OCHO_emit_max, 
           NEOP_emit_max, DMM_emit_max, MPRK_emit_max, C3ME3CO2H_emit_max, IBUTACID_emit_max, 
           PENTACID_emit_max, C6H13CO2H_emit_max, M2PEBOH_emit_max, CH3CL_emit_max, 
           CO24C5_emit_max, DMS_emit_max, ETBE_emit_max, CH3BR_emit_max, HEXAOH_emit_max, 
           HEX2ONE_emit_max, CHCL2CH3_emit_max, DMSO2_emit_max, DIEK_emit_max, PEBOH_emit_max, 
           HEX3ONE_emit_max, TOLUENE_emit_max, PROPGLY_emit_max, BENZENE_emit_max, MXYL_emit_max, 
           ETHGLY_emit_max, TPENT2ENE_emit_max, CPENT2ENE_emit_max, TRICLETH_emit_max, 
           EBENZ_emit_max, OXYL_emit_max, TM124B_emit_max, STYRENE_emit_max, MGLYOX_emit_max, 
           GLYOX_emit_max, PHENOL_emit_max, PR2OHMOX_emit_max, METHTOL_emit_max, 
           OETHTOL_emit_max, THEX2ENE_emit_max, HCOOH_emit_max, TM135B_emit_max, 
           IBUTOL_emit_max, CYHEXONE_emit_max, BENZAL_emit_max, CHCL3_emit_max, PBENZ_emit_max, 
           IPBENZ_emit_max, ME3BUT1ENE_emit_max, PETHTOL_emit_max, METHACET_emit_max, 
           CATECHOL_emit_max, OXYLAL_emit_max, CYHEXOL_emit_max, CDICLETH_emit_max, 
           TDICLETH_emit_max, CRESOL_emit_max, C6H5CH2OH_emit_max, EOX2EOL_emit_max, 
           PXYL_emit_max, MALANHY_emit_max, ACO2H_emit_max, ETHOX_emit_max, MTBE_emit_max, 
           VINCL_emit_max, DIBRET_emit_max, CH3CCL3_emit_max, MXYLAL_emit_max, PHCOOH_emit_max, 
           BPINENE_emit_max, C3ME3CHO_emit_max, PHCOME_emit_max, BUT2OLO_emit_max, 
           BCARY_emit_max, EBENZOL_emit_max, M3F_emit_max, LIMONENE_emit_max, PHIC3OH_emit_max, 
           CCL2CH2_emit_max, CL12PROP_emit_max, TM123BCHO_emit_max, DNCRES_emit_max, ALLYLOH_emit_max, 
           DNPHEN_emit_max, BUT2CHO_emit_max, HOC6H4NO2_emit_max,
           NO_init_max, NO2_init_max, NO3_init_max, N2O5_init_max, HONO_init_max, 
           HNO3_init_max, HNO4_init_max, O3_init_max, O1D_init_max, O3P_init_max, 
           OH_init_max, HO2_init_max, H2O2_init_max, CO_init_max, SO2_init_max, 
           H2SO4_init_max, NH3_init_max, HCL_init_max, CH4_init_max, C2H6_init_max, 
           CH3O2_init_max, ETHP_init_max, HCHO_init_max, CH3OH_init_max, CH3OOH_init_max, 
           ETHOOH_init_max, ALD2_init_max, HCOOH_init_max, PAR_init_max, AONE_init_max, 
           MGLY_init_max, ETH_init_max, OLET_init_max, OLEI_init_max, TOL_init_max, 
           XYL_init_max, CRES_init_max, TO2_init_max, CRO_init_max, OPEN_init_max, 
           ONIT_init_max, PAN_init_max, RCOOH_init_max, ROOH_init_max, C2O3_init_max, 
           RO2_init_max, ANO2_init_max, NAP_init_max, ARO1_init_max, ARO2_init_max, 
           ALK1_init_max, OLE1_init_max, XO2_init_max, XPAR_init_max, ISOP_init_max, 
           API_init_max, LIM_init_max, API1_init_max, API2_init_max, LIM1_init_max, 
           LIM2_init_max, ISOPRD_init_max, ISOPP_init_max, ISOPN_init_max, ISOPO2_init_max, 
           DMS_init_max, MSA_init_max, DMSO_init_max, DMSO2_init_max, CH3SO2H_init_max, 
           CH3SCH2OO_init_max, CH3SO2_init_max, CH3SO3_init_max, CH3SO2OO_init_max,
           pres_max,
           SO2_phase_max, NO2_phase_max, NO_phase_max, NH3_phase_max, CO_phase_max, DMS_phase_max, C2H5OH_phase_max, CH4_phase_max, CH3COCH3_phase_max, IPROPOL_phase_max, CH3OH_phase_max, IC5H12_phase_max, C3H8_phase_max, OXYL_phase_max, NC4H10_phase_max, C2H4_phase_max, BUOX2ETOH_phase_max, IC4H10_phase_max, HCHO_phase_max, NC6H14_phase_max, M2PE_phase_max, MEK_phase_max, LIMONENE_phase_max, NC5H12_phase_max, C3H6_phase_max, C2H2_phase_max, M3PE_phase_max, NC7H16_phase_max, CH3CHO_phase_max, IPROACET_phase_max, CHEX_phase_max, NPROACET_phase_max, CH3CCL3_phase_max, CH3OCH3_phase_max, ME2BUT2ENE_phase_max, NBUTACET_phase_max, M23C4_phase_max, C2H6_phase_max, C4H6_phase_max, MIBK_phase_max, ETHACET_phase_max, PENT1ENE_phase_max, BUT1ENE_phase_max, CH3CO2H_phase_max, M2HEX_phase_max, BOX2PROL_phase_max, ME2BUT1ENE_phase_max, ACR_phase_max, CBUT2ENE_phase_max, MEPROPENE_phase_max, HEX1ENE_phase_max, C2H5CHO_phase_max, C4ALDB_phase_max, BUT2OL_phase_max, M3HEX_phase_max, NC10H22_phase_max, NC11H24_phase_max, NBUTOL_phase_max, NC12H26_phase_max, DIETETHER_phase_max, M22C4_phase_max, NC8H18_phase_max, MIBKAOH_phase_max, C3H7CHO_phase_max, C5H11CHO_phase_max, C6H13CHO_phase_max, NPROPOL_phase_max, NC9H20_phase_max, BIACET_phase_max, APINENE_phase_max, MACR_phase_max, EGLYOX_phase_max, PROPACID_phase_max, C4H9CHO_phase_max, TBUTOL_phase_max, MO2EOL_phase_max, METHCOACET_phase_max, BUTACID_phase_max, CH3CH2CL_phase_max, TBUACET_phase_max, CH3OCHO_phase_max, NEOP_phase_max, DMM_phase_max, MPRK_phase_max, C3ME3CO2H_phase_max, IBUTACID_phase_max, PENTACID_phase_max, C6H13CO2H_phase_max, M2PEBOH_phase_max, CH3CL_phase_max, CO24C5_phase_max, DMS_phase_max, ETBE_phase_max, CH3BR_phase_max, HEXAOH_phase_max, HEX2ONE_phase_max, CHCL2CH3_phase_max, DMSO2_phase_max, DIEK_phase_max, PEBOH_phase_max, HEX3ONE_phase_max, TOLUENE_phase_max, PROPGLY_phase_max, BENZENE_phase_max, MXYL_phase_max, ETHGLY_phase_max, TPENT2ENE_phase_max, CPENT2ENE_phase_max, TRICLETH_phase_max, EBENZ_phase_max, OXYL_phase_max, TM124B_phase_max, STYRENE_phase_max, MGLYOX_phase_max, GLYOX_phase_max, PHENOL_phase_max, PR2OHMOX_phase_max, METHTOL_phase_max, OETHTOL_phase_max, THEX2ENE_phase_max, HCOOH_phase_max, TM135B_phase_max, IBUTOL_phase_max, CYHEXONE_phase_max, BENZAL_phase_max, CHCL3_phase_max, PBENZ_phase_max, IPBENZ_phase_max, ME3BUT1ENE_phase_max, PETHTOL_phase_max, METHACET_phase_max, CATECHOL_phase_max, OXYLAL_phase_max, CYHEXOL_phase_max, CDICLETH_phase_max, TDICLETH_phase_max, CRESOL_phase_max, C6H5CH2OH_phase_max, EOX2EOL_phase_max, PXYL_phase_max, MALANHY_phase_max, ACO2H_phase_max, ETHOX_phase_max, MTBE_phase_max, VINCL_phase_max, DIBRET_phase_max, CH3CCL3_phase_max, MXYLAL_phase_max, PHCOOH_phase_max, BPINENE_phase_max, C3ME3CHO_phase_max, PHCOME_phase_max, BUT2OLO_phase_max, BCARY_phase_max, EBENZOL_phase_max, M3F_phase_max, LIMONENE_phase_max, PHIC3OH_phase_max, CCL2CH2_phase_max, CL12PROP_phase_max, TM123BCHO_phase_max, DNCRES_phase_max, ALLYLOH_phase_max, DNPHEN_phase_max, BUT2CHO_phase_max, HOC6H4NO2_phase_max])

lhs_prob = pyDOE.lhs(len(lhs_min), scenarios)
lhs = lhs_min + (lhs_max-lhs_min) * lhs_prob

# Calculate the temperature for each scenario
for i in range(lhs.shape[0]):
    print("********Scenario",str(i).zfill(4),"********")
    lat=(lhs[i,1])
    print("lat:","%.3f" % lat)
    doy=int(lhs[i,2])
    print("doy:",doy)
    
    min_temp, max_temp = DOY_lat_temp(doy, lat, df)
    print("min temperature:", "%.3f" % (min_temp-273.15))
    print("max temperature:", "%.3f" % (max_temp-273.15))
    
    print("Temperature factor", "%.3f" % lhs[i,3])
    lhs[i,3] = min_temp + (max_temp - min_temp) * lhs[i,3] 
    print("final temperature:", "%.3f" % (lhs[i,3]-273.15))
    print("\n")

print("The dimension of the Latin Hypercube Sampling is:",lhs.shape)
print("There are", str(lhs.shape[0]), "scenarios, and", str(lhs.shape[1]), "variables")

# Save the necessary matrix
np.savetxt("./lhs_prob.txt",lhs_prob)
np.savetxt("./lhs_min.txt",lhs_min)
np.savetxt("./lhs_max.txt",lhs_max)
np.savetxt("./lhs.txt",lhs)

# Load the matrix and distribute into different scenarios
lhs = np.loadtxt("./lhs.txt")
for i in range (lhs.shape[0]):
    directory = "./scenarios/scenario_" +  str(i).zfill(4)
    if not os.path.exists(directory):
        os.makedirs(directory)
    np.savetxt(directory+"/matrix_"+str(i).zfill(4)+".txt",lhs[i])
    
    # aero_data and gas_data
    shutil.copy("./dat_files/aero_data.dat",directory+"/aero_data.dat")
    shutil.copy("./dat_files/gas_data.dat",directory+"/gas_data.dat")
    
    # aero_back
    shutil.copy("./dat_files/aero_back_comp.dat",directory+"/aero_back_comp.dat")
    shutil.copy("./dat_files/aero_back_dist.dat",directory+"/aero_back_dist.dat")
    shutil.copy("./dat_files/aero_back.dat",directory+"/aero_back.dat")
    
    # aero_emit
    shutil.copy("./dat_files/aero_emit_comp_carbo.dat",directory+"/aero_emit_comp_carbo.dat")
    shutil.copy("./dat_files/aero_emit_comp_ss1.dat",directory+"/aero_emit_comp_ss1.dat")
    shutil.copy("./dat_files/aero_emit_comp_ss2.dat",directory+"/aero_emit_comp_ss2.dat")
    shutil.copy("./dat_files/aero_emit_comp_dust1.dat",directory+"/aero_emit_comp_dust1.dat")
    shutil.copy("./dat_files/aero_emit_comp_dust2.dat",directory+"/aero_emit_comp_dust2.dat")
    
    shutil.copy("./dat_files/aero_emit_dist.dat",directory+"/aero_emit_dist.dat")
    shutil.copy("./dat_files/aero_emit.dat",directory+"/aero_emit.dat")
    
    # aero_init
    shutil.copy("./dat_files/aero_init_comp.dat",directory+"/aero_init_comp.dat")
    shutil.copy("./dat_files/aero_init_dist.dat",directory+"/aero_init_dist.dat")
    
    # gas 
    shutil.copy("./dat_files/gas_back.dat",directory+"/gas_back.dat")
    shutil.copy("./dat_files/gas_emit.dat",directory+"/gas_emit.dat")
    shutil.copy("./dat_files/gas_init.dat",directory+"/gas_init.dat")
    
    # environment
    shutil.copy("./dat_files/temp.dat",directory+"/temp.dat")
    shutil.copy("./dat_files/pres.dat",directory+"/pres.dat")
    shutil.copy("./dat_files/height.dat",directory+"/height.dat")
    
    # .spec file
    shutil.copy("./dat_files/urban_plume_init.spec",directory+"/urban_plume_init.spec")
    shutil.copy("./dat_files/urban_plume_restart.spec",directory+"/urban_plume_restart.spec")
    
    # run.sh
    shutil.copy("./dat_files/1_run.sh",directory+"/1_run.sh")
