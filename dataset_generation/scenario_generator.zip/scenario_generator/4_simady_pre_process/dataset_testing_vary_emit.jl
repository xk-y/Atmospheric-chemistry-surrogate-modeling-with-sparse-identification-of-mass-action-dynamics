using JLD2, CSV, DataFrames
using KissSmoothing
using Statistics
using Plots
using Printf

ndays = 10
saveat = 60.0
dt = 60 # minutes
nruns = 1070
n_species = 5946
nmete = 5
ntimestep = 24*ndays +1
startspec = 1

begin
    specname =  Array(CSV.read("specname.csv", DataFrame))[startspec:n_species,2]

discard_specname = vcat(string.(specname[1:60]),["H2SO4", "ETHP", "ANOL", "ETHOOH", "ALD2", "RCOOH", "C2O3", "ARO1", "ARO2", "ALK1", "OLE1", "API1", "API2", "LIM1", "LIM2", "PAR", "AONE", "MGLY", "ETH", "OLET", "OLEI", "TOL", "XYL", "CRES", "TO2", "CRO", "OPEN", "ONIT", "ROOH", "RO2", "ANO2", "NAP", "XO2", "XPAR", "ISOP", "ISOPRD", "ISOPP", "ISOPN", "ISOPO2", "API", "LIM", "CH3SO2H", "CH3SCH2OO", "CH3SO2OO", "CH3SO2CH2OO", "SULFHOX", "NA", "SA"])
# Get indices of s in S
indices_s = findall(x -> x in discard_specname, specname)

# Get all indices of S
all_indices = collect(1:length(specname))

# Get indices that are not in s
non_s_indices = setdiff(all_indices, indices_s)

# Output the result
#println(non_s_indices)
specname = specname[non_s_indices]
end


for i in 0.25:0.25:2.00
    if i == 1.00
        continue
    end
JLD2.@load "testing_dataset_emit_$(@sprintf("%.2f", i)).jld" conc emit mete id
ref_data = conc[:,:,:][non_s_indices,:,:]
ref_emit = emit[:,:,:][non_s_indices,:,:]
conc = nothing
emit = nothing
GC.gc()



ref_data[ref_data.< 0.0] .= 0.0
#JLD2.@load "/projects/ctessum/xiaokai2/partmc-mcm/MCM-PartMC-MOSAIC-master/script/6_final_dataset/case_3750_20d/mete_$(nruns).jld" mete
ref_params = mete[:,1:ntimestep,:]

timelength = 60 * (ndays * 24) # minutes
times = LinRange(0, timelength, ntimestep)
#times = LinRange(0 , timelength, Int((timelength) / dt) + 1)
tspan = (times[1], times[end])
ref_data_test = ref_data
ref_emit_test = ref_emit
ref_params_test = ref_params
println(size(ref_data_test))
JLD2.jldsave("testing_set_emit_$(@sprintf("%.2f\n", i)).jld"; ref_data_test, ref_emit_test, ref_params_test, specname)
GC.gc()
end

