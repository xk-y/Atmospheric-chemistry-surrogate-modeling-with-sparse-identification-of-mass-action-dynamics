
using DataFrames, CSV

train = DataFrame(CSV.File("train_0000_0199.csv"))

emission = DataFrame(CSV.File("emit_0000_0199.csv"))

# Training data.
nspecs = 5946
nmete = 5
nfeature = nspecs + nmete

train_id = train[:,1:1]

train[!,5:size(train)[2]] = convert.(Float64,train[!,5:size(train)[2]])
train = train[:,5:nfeature+4]

emission = emission[1:size(emission)[1],(4):size(emission)[2]]
emission = emission[:,1:nfeature]

train[!,146] = train[!,146] .- train[1,146]#O2
train[!,147] = train[!,147] .- train[1,147]#CO2
train[!,149] = train[!,149] .- train[1,149]#N2

train[!,1] = train[!,1]#lat
train[!,2] = train[!,2]#temperature
train[!,3] = train[!,3].*1.0e2#RH
train[!,5] = train[!,5] .* 1.0e-5#pressure


for i in 6:65
    emission[:,i] .= emission[:,i] .* log(2) #.* 1e-3
    train[:,i] .= train[:,i] .* log(2)
end 

train[:,63:65] .= 0e0

#emission = emission[1:size(emission)[1],(nmete+1):size(emission)[2]]
println("")

size(train)#,size(emission)

findmax(Array(train)),findmin(Array(train))#,findmax(Array(emission)),findmin(Array(emission))

any(ismissing, Array(train))#,any(ismissing, Array(emission))

CSV.write("train_normalized_0000_0199.csv", Float32.(train))
CSV.write("emit_normalized_0000_0199.csv", Float32.(emission))
CSV.write("train_id_normalized_0000_0199.csv", Float32.(train_id))


