#!/usr/bin/env python
# coding: utf-8

# How to run this code? For scenario 0000 to 0099
# python get_nc_new.py 3586369 0 99

# ref: https://janakiev.com/blog/python-shell-commands/
import os
import sys
from tqdm import tqdm
import json

# define the parameters for the command
with open("./path_dict.json",'r') as load_f:
    load_dict = json.load(load_f)
    #print(json.dumps(load_dict, indent = 4))
    p1 = load_dict["path_before_jobs"]
    job_id = load_dict["job_id"]
    p2 = load_dict["path_after_jobs"]
    sc_number_start = int(load_dict["sc_number_start"])
    sc_number_end = int(load_dict["sc_number_end"])
    sh_filename = load_dict["sh_file_name"]

# define the original directory
oridir = os.getcwd()

for i in tqdm(range(sc_number_start, sc_number_end+1)):
    sc_id = "%04i" %i  #define the file number
#     print("scenario id:", sc_id)
    
    dest = p1+job_id+p2+sc_id+"/"
    dest_file = dest+sh_filename

    # define the command
    cpcmd = "cp"+" "+oridir+"/"+sh_filename+" "+dest_file #copy
    # cdcmd = "cd" # change the directory
    execmd = "bash"+" "+sh_filename # run the bash command
#     print(cpcmd)
#     print("\n")
#     print(dest)
#     print("\n")
#     print(execmd)
#     print("\n")

    # run the command
    os.system(cpcmd) # copy
    os.chdir(dest) # change the directory
    os.system(execmd)
print("Finished the postprocessing (get nc files)! \n")
