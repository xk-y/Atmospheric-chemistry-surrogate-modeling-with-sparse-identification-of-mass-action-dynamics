import xarray as xr
import pandas as pd
import numpy as np
import gc
import time
import sys
from tqdm import tqdm
import json

# how to use this script?
# python get_csv_new.py 3590575 train 0 29
        
def get_aero_data(job_id, sc_id, p1, p2, p3):
    """
    Unit in ug/m3
    """

    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p3 = "/out/urban_plume_psd_bins_2d.nc"

    aero_ls = ['so4_conc','no3_conc','cl_conc','nh4_conc','msa_conc',
               'aro1_conc','aro2_conc','alk1_conc','ole1_conc','api1_conc',
               'api2_conc','lim1_conc','lim2_conc','co3_conc','na_conc',
               'ca_conc','oin_conc','oc_conc','bc_conc','h2o_conc']
               



    aero_col_names = []
    for aero in aero_ls:
        for i in range(1,4):
            aero_col_names.append(aero+"_"+str(i))

    aero_nc = xr.open_dataset(p1+job_id+p2+sc_id+p3)[aero_ls]  # open the .nc file
    df_aero = aero_nc.to_dataframe().reset_index().set_index(["centers","time"]).unstack(level=0)
    df_aero.columns = aero_col_names 

    df_aero = df_aero.reset_index()
    df_aero[aero_col_names] = df_aero[aero_col_names]*1.0e9 # convert unit
    df_aero["sc_id"] = sc_id
    
    return df_aero[["sc_id","time"]+aero_col_names], aero_col_names

# extract the environmental variables and gas species from partmc raw output
def single_scenario(job_id, sc_id, time_length, p1, p2, p4):
    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p4 = "/out/urban_plume_0001_"
    
    # define the lists
    time_ls = []
    rh_ls = []
    gas_ls = []
    temperature_ls = []
    sza_ls = []
    lat_ls = []
    pressure_ls = [] #2021.3.4
    file_ls = []
    sc_ls = []
    dense_ls = []
    #mg_ls = []
    #n_emit_ls = []
    # define the flag for gas species
    gas_name_flag = True

    for i in range(1,1+time_length):
        file = "%08i" %i  #define the file number
        # print(p1+job_id+p2+sc_id+p4+file+".nc")
        ds = xr.open_dataset(p1+job_id+p2+sc_id+p4+file+".nc")
        ds_aer = xr.open_dataset(p1+job_id+p2+sc_id+p3)
        sc_ls.append(sc_id)
        file_ls.append(file)
        
        time_ls.append(np.array(ds["time"]))
        rh_ls.append(np.array(ds["relative_humidity"]))
        temperature_ls.append(np.array(ds["temperature"]))
        sza_ls.append(np.array(ds["solar_zenith_angle"]))
        lat_ls.append(np.array(ds["latitude"]))
        pressure_ls.append(np.array(ds["pressure"]))#2021.3.4
        dense_ls.append(np.array(ds_aer["molar_den"][0]))
        gas_ls.append(ds.gas_mixing_ratio.to_pandas())
        
        #mg_ls.append(np.array(ds["weight_magnitude"]))
        #n_emit_ls.append(np.array(ds["aero_emission_n_part"])) 
        if gas_name_flag:
            gas_names_ls = ds.gas_species.names.split(",")
            gas_name_flag = False

        del ds
        gc.collect()

    df = pd.concat(gas_ls,axis=1).transpose().reset_index().drop(['index'],axis=1)
    df.columns = gas_names_ls
    
    df["sc_id"] = sc_ls
    df["time_id"] = file_ls
    df["time"] = np.array(time_ls)
    df["RELHUM"] = rh_ls
    df["T"] = temperature_ls
    df["SZA"] = sza_ls
    df["lat"] = lat_ls
    df["pressure"] = pressure_ls
    df["air_den"] = dense_ls
    #df["magnitude"] = mg_ls
    #df["n_emit"] = n_emit_ls
    #env_ls = ["time_id","lat","T","RELHUM","SZA","pressure","magnitude","n_emit"]#2021.3.4
    env_ls = ["time_id","air_den","lat","T","RELHUM","SZA","pressure"]
    return df[["sc_id","time"]+env_ls+gas_names_ls], gas_names_ls, env_ls

def multi_scenarios(job_id, sc_number_start, sc_number_end, time_length, p1, p2, p3, p4):
    vari_ls = []
    print("Now it starts working on:", p1+job_id+p2+"****")
    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p5 = "/out/urban_plume_chi.nc"
    
    for i in tqdm(range(sc_number_start, sc_number_end+1)):
        sc_id = "%04i" %i  #define the file number
        # print("scenario id:", sc_id)
        
        # # get mixing state metrics
        # msm_nc = xr.open_dataset(p1+job_id+p2+sc_id+p5)
        # msm = msm_nc[['chi_hyg','chi_opt1','chi_opt2','chi_opt3','chi_abd']].to_dataframe().reset_index()
        
        # get aero variables
        aero, aero_names_ls = get_aero_data(job_id, sc_id, p1, p2, p3)

        # get environmental and gas variables
        gas_env, gas_names_ls, env_ls = single_scenario(job_id, sc_id, time_length, p1, p2, p4)
        # print("\n")
        
        # merge gas and env with aerosols 
        gas_env_aero = pd.merge(aero, gas_env, how = "inner", on = ["sc_id","time"])

        # merge environmental, gas, and mixing state metrics within scenario
        # gas_env_msm = pd.merge(gas_env, msm, how = "left", on = "time")
        # gas_env_msm_aero = pd.merge(gas_env_msm, aero, how = "left", on = "time")
        



        vari_ls.append(gas_env_aero[["sc_id","time"]+env_ls+aero_names_ls+gas_names_ls])
        # del msm_nc, msm, gas_env, aero, gas_env_msm, gas_env_msm_aero
        del gas_env, aero, gas_env_aero, env_ls, aero_names_ls, gas_names_ls
        gc.collect()
        
    # concat the df from different scenarios    
    df_final = pd.concat(vari_ls).reset_index(drop=True) 
    return df_final

def get_aero_emission_data(job_id, sc_id, p1, p2, p3):
    """
    Unit in ug/m3
    """

    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p3 = "/out/urban_plume_psd_bins_2d.nc"

    aero_emission_ls = ['so4_conc_emission','no3_conc_emission','cl_conc_emission',
                        'nh4_conc_emission','msa_conc_emission','aro1_conc_emission',
                        'aro2_conc_emission','alk1_conc_emission','ole1_conc_emission',
                        'api1_conc_emission','api2_conc_emission','lim1_conc_emission',
                        'lim2_conc_emission','co3_conc_emission','na_conc_emission',
                        'ca_conc_emission','oin_conc_emission','oc_conc_emission',
                        'bc_conc_emission','h2o_conc_emission']
                       
    aero_emission_col_names = []
    for aero in aero_emission_ls:
        for i in range(1,4):
            aero_emission_col_names.append(aero+"_"+str(i))

    aero_emission_nc = xr.open_dataset(p1+job_id+p2+sc_id+p3)[aero_emission_ls]  # open the .nc file
    df_aero_emission = aero_emission_nc.to_dataframe().reset_index().set_index(["centers","time"]).unstack(level=0)
    df_aero_emission.columns = aero_emission_col_names 
    df_aero_emission = df_aero_emission.reset_index()
    df_aero_emission[aero_emission_col_names] = df_aero_emission[aero_emission_col_names]*1.0e9 # convert unit
    df_aero_emission["sc_id"] = sc_id
    
    return df_aero_emission[["sc_id","time"]+aero_emission_col_names], aero_emission_col_names
    
    
# extract the environmental variables and gas species from partmc raw output
def single_scenario_emission(job_id, sc_id, time_length, p1, p2, p4):
    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p4 = "/out/urban_plume_0001_"
    
    # define the lists
    time_ls = []
    #rh_ls = []
    gas_emission_ls = []
    #temperature_ls = []
    #sza_ls = []
    #lat_ls = []
    #pressure_ls = [] #2021.3.4
    file_ls = []
    sc_ls = []
    # define the flag for gas species
    gas_name_flag = True

    for i in range(1,1+time_length):
        file = "%08i" %i  #define the file number
        # print(p1+job_id+p2+sc_id+p4+file+".nc")
        ds = xr.open_dataset(p1+job_id+p2+sc_id+p4+file+".nc")
        
        sc_ls.append(sc_id)
        file_ls.append(file)
        
        time_ls.append(np.array(ds["time"]))
        #rh_ls.append(np.array(ds["relative_humidity"]))
        #temperature_ls.append(np.array(ds["temperature"]))
        #sza_ls.append(np.array(ds["solar_zenith_angle"]))
        #lat_ls.append(np.array(ds["latitude"]))
        #pressure_ls.append(np.array(ds["pressure"]))#2021.3.4
        gas_emission_ls.append(ds.gas_emission.to_pandas())

        if gas_name_flag:
            gas_names_ls = ds.gas_species.names.split(",")
            gas_name_flag = False

        del ds
        gc.collect()

    df = pd.concat(gas_emission_ls,axis=1).transpose().reset_index().drop(['index'],axis=1)
    df.columns = gas_names_ls
    
    df["sc_id"] = sc_ls
    df["time_id"] = file_ls
    df["time"] = np.array(time_ls)
    df["RELHUM"] = 0.0e0
    df["T"] = 0.0e0
    df["SZA"] = 0.0e0
    df["lat"] = 0.0e0
    df["pressure"] = 0.0e0
    env_ls = ["time_id","lat","T","RELHUM","SZA","pressure"]
    
    return df[["sc_id","time"]+env_ls+gas_names_ls], gas_names_ls, env_ls

def multi_scenarios_emission(job_id, sc_number_start, sc_number_end, time_length, p1, p2, p3, p4):
    vari_ls = []
    print("Now it starts working on:", p1+job_id+p2+"****")
    # p1 = "/data/keeling/a/zzheng25/d/partmc-mam4-high-lat/"
    # p2 = "/scenarios/scenario_"
    # p5 = "/out/urban_plume_chi.nc"
    
    for i in tqdm(range(sc_number_start, sc_number_end+1)):
        sc_id = "%04i" %i  #define the file number
        # print("scenario id:", sc_id)
        
        # # get mixing state metrics
        # msm_nc = xr.open_dataset(p1+job_id+p2+sc_id+p5)
        # msm = msm_nc[['chi_hyg','chi_opt1','chi_opt2','chi_opt3','chi_abd']].to_dataframe().reset_index()
        
        # get aero variables
        aero, aero_names_ls = get_aero_emission_data(job_id, sc_id, p1, p2, p3)

        # get environmental and gas variables
        gas_env, gas_names_ls, env_ls = single_scenario_emission(job_id, sc_id, time_length, p1, p2, p4)
        # print("\n")
        
        # merge gas and env with aerosols 
        gas_env_aero = pd.merge(aero, gas_env, how = "inner", on = ["sc_id","time"])

        # merge environmental, gas, and mixing state metrics within scenario
        # gas_env_msm = pd.merge(gas_env, msm, how = "left", on = "time")
        # gas_env_msm_aero = pd.merge(gas_env_msm, aero, how = "left", on = "time")
        



        vari_ls.append(gas_env_aero[["sc_id","time"]+env_ls+aero_names_ls+gas_names_ls])
        # del msm_nc, msm, gas_env, aero, gas_env_msm, gas_env_msm_aero
        del gas_env, aero, gas_env_aero, env_ls, aero_names_ls, gas_names_ls
        gc.collect()
        
    # concat the df from different scenarios    
    df_final = pd.concat(vari_ls).reset_index(drop=True) 
    return df_final

with open("./path_dict.json",'r') as load_f:
    load_dict = json.load(load_f)
    #print(json.dumps(load_dict, indent = 4))
    p1 = load_dict["path_before_jobs"]
    job_id = load_dict["job_id"]
    p2 = load_dict["path_after_jobs"]
    sc_number_start = int(load_dict["sc_number_start"])
    sc_number_end = int(load_dict["sc_number_end"])
    time_length = int(load_dict["time_length"])
    p3 = load_dict["post_nc"]
    p4 = load_dict["single_nc_prefix"]
    save_train_path = load_dict["save_train_name"]
    save_emit_path = load_dict["save_emit_name"]


df = multi_scenarios(job_id, sc_number_start, 
    sc_number_end, time_length, p1, p2, p3, p4)
df = df.astype(np.float32)
df= df.fillna((np.float32(0)))
df.to_csv(save_train_path ,index=False)

df_emission = multi_scenarios_emission(job_id, sc_number_start, 
    sc_number_end, time_length, p1, p2, p3, p4)
df_emission = df_emission.astype(np.float32)
df_emission= df_emission.fillna((np.float32(0)))
df_emission.to_csv(save_emit_path ,index=False)
